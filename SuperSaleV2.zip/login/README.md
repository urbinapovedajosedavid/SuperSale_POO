# SuperSale_POO

Repositorio: https://github.com/urbinapovedajosedavid/SuperSale_POO

Descripción
- Proyecto de gestión desarrollado en Java (NetBeans), con interfaz de escritorio y conexión a base de datos MySQL.

Requisitos previos
- Java Development Kit (JDK) 21

- XAMPP (o MySQL/MariaDB + phpMyAdmin) instalado y funcionando para la base de datos.

Importar la base de datos usando phpMyAdmin
1. Inicie XAMPP (o el servicio de MySQL) y asegúrese de que `Apache` y `MySQL` estén activos tocandole STAR
2. Abra phpMyAdmin en su navegador: `http://localhost/phpmyadmin/`.
3. Cree una nueva base de datos (por ejemplo: `supersale_db`) o seleccione la base de datos destino.
4. Vaya a la pestaña “Importar”.
5. Pulse “Examinar…” y seleccione el script SQL ubicado en la carpeta, `REQUISITOS_BASE_DE_DATOS`, luego ingresa ala siguiente carpeta ,`archivo SQL` del repositorio.
6. Mantenga las opciones por defecto y pulse “Continuar” para ejecutar la importación.
7. Verifique que las tablas y los registros se hayan creado correctamente.

Configuración de la conexión
- Editar `login/src/Data_base/Conexion.java` para ajustar:
  - `URL` (host, puerto, nombre de la base de datos)
  - `usuario` y `password`

esto ya lo trae despues de descargarlo 
/**************************************************************************************************/
Ejecutar el archivo .jar desde la carpeta `dist`
1. Abra una terminal y navegue a la carpeta `dist` dentro del proyecto:

```
cd path\to\SuperSale_POO\dist
```

2. Ejecute el JAR con:

```
java -jar SuperSale_POO.jar
```
/*********************************************************************************************************/


Notas importantes
- Si el nombre del JAR es distinto, sustituya `SuperSale_POO.jar` por el nombre real del archivo en `dist`.
- Asegúrese de que la base de datos esté en funcionamiento antes de ejecutar la aplicación para evitar errores de conexión.
- Si su rama principal no es `main`, la descarga directa de ZIP desde GitHub puede usar `master` u otra rama.

Estructura relevante
- `login/` — Código fuente del proyecto Java.
- `database/` — Script(s) SQL para crear la base de datos y poblarla.
- `dist/` — Ejecutable `.jar` listo para distribuir.


- Para dudas o soporte, abra un issue en el repositorio de GitHub o contacte con David Poveda
